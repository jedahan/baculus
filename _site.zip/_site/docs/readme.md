An more general introduction to our research can be found on https://jedahan.com/baculus/research , but we invite you to read the WIP documents here!

![block diagram](./block_diagram.png)
