Here we provide useful tools to develop locally using docker

To make the scuttlebot:dev docker image, run `make`

To run bash as the node user, with link local only addresses, `make run`

To run bash as the node user, with full network addresses `make net`
